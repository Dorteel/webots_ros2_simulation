# Egg carton Webots asset

Copy `EggCarton.proto`, `egg_carton.obj`, and `egg_carton.mtl` into the same
Webots `protos/` directory. Insert it with:

```vrml
EggCarton {
  translation 0 0 0.8
  name "egg_carton"
}
```

The open six-egg carton is approximately 0.18 x 0.15 x 0.12 m including its
raised lid. The base footprint is 0.18 x 0.11 m. Mass is 0.50 kg. The preview
PNG is for inspection only and is not needed by Webots.

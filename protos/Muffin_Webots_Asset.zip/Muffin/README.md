# Muffin Webots asset

Copy `Muffin.proto`, `muffin.obj`, and `muffin.mtl` into the same Webots
`protos/` directory. Insert it with:

```vrml
Muffin {
  translation 0 0 0.8
  name "muffin"
}
```

The chocolate-chip muffin is approximately 0.09 m wide and 0.086 m tall. It
has a fluted paper wrapper, irregular baked dome and embedded chips. Mass is
0.12 kg. The preview PNG is not needed by Webots.
